## EaglercraftBungee

This is regular BungeeCord except it accepts WebSockets instead of raw TCP connections

**For an animated MOTD, place 'EaglerMOTDPlugin.jar' into the 'plugins' folder.  
Configuration: [https://github.com/LAX1DUDE/eaglercraft-motd/](https://github.com/LAX1DUDE/eaglercraft-motd/)**