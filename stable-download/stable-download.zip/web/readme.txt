
This folder is displaying an update notice to replit users still running an old version of the update script

Go to the stable-download-new.zip to get the latest website files
