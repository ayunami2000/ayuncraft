
This folder is displaying an update notice to replit users still running an old version of the update script

Go to the ../web_folder to get the latest website files
